package com;

public class vdvd {
	public static void main(String[] args){ 
        String url = "http://60.194.106.82:10053/H5Webkpgl/eiInterface.action";
        String jsonStr = "{s:ss}";
        String httpOrgCreateTestRtn = HttpClientUtil.doPost(url, jsonStr, "utf-8");
    }
}
